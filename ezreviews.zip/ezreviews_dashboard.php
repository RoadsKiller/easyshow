<?php
/**
 * Plugin Name: EZReviews
 * Plugin URI:  http://yourwebsite.com
 * Description: A simple plugin to show the latest trustpilot reviews. The minimum required version for WordPress is 6.7.1.
 * Version:     1.0
 * Author:      Hoo
 * Author URI:  http://yourwebsite.com
 */

if (!defined('ABSPATH')) {
    exit;
}

function cur_activate_plugin() { }
register_activation_hook(__FILE__, 'cur_activate_plugin');

function cur_deactivate_plugin() { }
register_deactivation_hook(__FILE__, 'cur_deactivate_plugin');

// 插件显示的信息
function cur_admin_menu() {
    add_menu_page('EZReviews', 'EZReviews', 'manage_options', 'custom-url-request', 'cur_admin_page', 'dashicons-admin-links');
}
add_action('admin_menu', 'cur_admin_menu');

function cur_admin_page() {
    // 获取插件目录的URL
    $plugin_url = plugin_dir_url(__FILE__);
    ?>
    <div class="wrap">
        <h1>EZReviews</h1>
        <div class="container">
            <h1>✨ Please Search the Domain's Status ✨</h1>
            <input class="domain" type="text" id="domainInput" placeholder="example.com">
            <div class="btnArea clearfix">
                <div class="charge-content fl">
                    <a href="https://www.google.com" target="_blank">
                        <button type="button" class="chargeBtn">🔥 Go to Charge</button>
                    </a>
                </div>
                <button type="button" id="searchButton" class="searchBtn fl">🔍 Search The Domain's Status</button>
            </div>
            
            <div id="responseArea"></div>
            
            <h2 class="display-title">Display Effects</h2>
            <div class="effect clearfix">
                <div class="effect-img fl">
                    <div class="effect-title">PC Effect</div>
                    <img src="<?php echo $plugin_url . 'img/PC.png'; ?>" alt="" />
                </div>
                <div class="effect-img fl">
                    <div class="effect-title">IPad Effect</div>
                    <img src="<?php echo $plugin_url . 'img/IPad.png'; ?>" alt="" />
                </div>
                <div class="effect-img fr">
                    <div class="effect-title">Mobile Effect</div>
                    <img src="<?php echo $plugin_url . 'img/Mobile.png'; ?>" alt="" />
                </div>
            </div>
        </div>
    </div>
    <script type="text/javascript">
        jQuery(document).ready(function($) {
            $('#searchButton').click(function(){
                var domain = $('#domainInput').val();
                var apiUrl = "https://elegantcenter.sale/paygateway/getTrustpilotDataById?dataId=https://www.trustpilot.com/review/" + encodeURIComponent(domain);
                console.log("点击了搜索按钮");
                
                    $.get(apiUrl, function(response) {
                        // 解析最外层的JSON对象
                        var parsedResponse = JSON.parse(response);
                        var resCode = parsedResponse.code; // 状态码
                        var resData = parsedResponse.data; // 里面的值 string
                        // console.log(resCode, resData);

                        var expireContent = '';
                        var dataContent = '';
                        
                        if (resCode === "0000") {
                            // console.log("成功获取", resData);
                            //resData = resData.replace(/'/g, '"'); // 将单引号换成双引号，目的是便于待会转JSON
                            
                            var resDataJSON = JSON.parse(resData); // 转成了JSON，就可以通过 . 的形式来获取里面的信息
                            
                            /** 发送数据到PHP函数保存到Transient */
                            $.post(ajaxurl, {
                                action: 'save_transient_data',
                                data: resDataJSON // 发送整个对象到后端
                            }, function(response) {
                                console.log(response); // 打印响应状态
                            });

                            var expireTime = resDataJSON.expire; // 到期时间
                            console.log("expireTime: " + expireTime);

                            var trustpilotUrl = resDataJSON.trustpilot_url;
                            var gradesName = resDataJSON.grades_name;
                            var gradesImg = resDataJSON.grades_img;
                            var rvTotalNum = resDataJSON.rv_total_num;
                            var reviews = resDataJSON.reviews;
                            console.log("trustpilotUrl: " + trustpilotUrl);
                            console.log("gradesName: " + gradesName);
                            console.log("gradesImg: " + gradesImg);
                            console.log("rvTotalNum: " + rvTotalNum);
                            console.log("reviews: " + reviews);
                            // console.log(reviews instanceof Array); // true

                            // 判断用户输入的域名是否到期
                            if (expireTime <= 0) {
                                expireContent += '<div class="details"><div class="search"><div class="search-error">The domain has expired.</div></div></div>';
                            }
                            else {
                                // 构建显示内容
                                dataContent += '<div class="details">'
                                dataContent += '<div class="search">'
                                dataContent += '<div class="search-res">Expire Status: ' + expireTime + ' days until expiration.</div>';
                                // dataContent += '<div class="search-res">Content: ' + contentAllData + '</div>';
                                dataContent += '<div class="search-res">You can use this shortcode [easy_reviews] to display the reviews anywhere on front pages.';
                                dataContent += '</div>'
                                dataContent += '</div>'
                            }
                        }
                        else {
                            // API返回错误代码处理
                            dataContent = '<div class="details"><div class="search"><div class="search-error">Invalid input type or the domain is not activated.</div></div></div>';
                        }

                        // 在页面上显示结果
                        var finalContent = dataContent + expireContent; // 合并dataContent和expireContent
                        $('#responseArea').html(finalContent);
                    }).fail(function() {
                        $('#responseArea').html('<div class="details"><div class="search"><div class="search-error">Error retrieving data.</div></div></div>');
                    });
            });

        });

    </script>
    <?php
}

function cur_enqueue_styles() {
    wp_enqueue_style('cur-custom-style', plugin_dir_url(__FILE__) . 'css/front.css');
}
add_action('admin_enqueue_scripts', 'cur_enqueue_styles');

/**第一步：设置一个用于保存数据到Transient的PHP函数 */
function save_data_to_transient() {
    if (!current_user_can('manage_options')) {
        wp_die('Lack of permissions');
    }

    $data = $_POST['data']; // 获取从前端传递的数据
    if (!empty($data)) {
        set_transient('tp_data_transient', $data, 0); // 保存数据到Transient,永久缓存
        
        wp_send_json_success('Data saved successfully.');
    } else {
        wp_send_json_error('No data provided.');
    }
}
add_action('wp_ajax_save_transient_data', 'save_data_to_transient'); // 注册AJAX action

/** 注册短代码 */
// 注册短代码 [easy_reviews]
function easy_reviews_shortcode() {
    // 开启输出缓冲区
    ob_start();

    // 确保包含 tp_plugin.php 文件
    $plugin_dir = plugin_dir_path(__FILE__);
    include $plugin_dir . 'tp_plugin.php';

    // 获取缓冲区内容并清除缓冲区
    return ob_get_clean();
}
add_shortcode('easy_reviews', 'easy_reviews_shortcode');

// 加载插件资源
function easy_reviews_enqueue_scripts() {
    $plugin_url = plugin_dir_url(__FILE__); // 获取插件的URL

    // 加载CSS文件
    wp_enqueue_style('easy-reviews-style', $plugin_url . 'css/index1.css');
    wp_enqueue_style('swiper-style', $plugin_url . 'css/swiper-bundle.min.css');

    // 加载JS文件
    wp_enqueue_script('swiper-script', $plugin_url . 'js/swiper-bundle.min.js', array('jquery'), null, true);
}
add_action('wp_enqueue_scripts', 'easy_reviews_enqueue_scripts');


// 拿到缓存中的url
function getTransientURL(){
    $transient_data = get_transient('tp_data_transient');
    if (!empty($transient_data) && isset($transient_data['trustpilot_url'])) {
        $trustpilot_url = esc_html($transient_data['trustpilot_url']);
        echo "<div class='notice notice-success is-dismissible'>
                <p><strong>EZReviews URL:</strong> $trustpilot_url</p>
              </div>";
    } else {
        echo "<div class='notice notice-error is-dismissible'>
                <p><strong>Please input a correct URL in the input form.</strong></p>
              </div>";
    }
}

// 在后台页面顶部或底部显示 trustpilot_url
add_action('admin_notices', 'getTransientURL');

// 去url中获取数据
function useURLToGetData(){
    $transient_data = get_transient('tp_data_transient');
    $transient_url = $transient_data['trustpilot_url'];

    if ($transient_url) {
        echo "
            <script type='text/javascript'>
                var url = '$transient_url';
                console.log('EZReviews URL:', url);
                var apiUrl = \"https://elegantcenter.sale/paygateway/getTrustpilotDataById?dataId=\" + url;
                
                var timerId = setInterval(function(){
                    jQuery(document).ready(function($) {
                        $.get(apiUrl, function(response) {
                                // 解析最外层的JSON对象
                                var parsedResponse = JSON.parse(response);
                                var resCode = parsedResponse.code; // 状态码
                                var resData = parsedResponse.data; // 里面的值 string
                                
                                if (resCode === \"0000\") {
                                    
                                    var resDataJSON = JSON.parse(resData); // 转成了JSON，就可以通过 . 的形式来获取里面的信息
                                    
                                    /** 发送数据到PHP函数保存到Transient */
                                    $.post(ajaxurl, {
                                        action: 'save_transient_data',
                                        data: resDataJSON // 发送整个对象到后端
                                    }, function(response) {
                                        console.log(response); // 打印响应状态
                                    });
                                    
                                }

                            }).fail(function() {
                                
                            });
                    })
                
                }, 60000);

                
            </script>
        ";
    }

    
}

add_action('admin_footer', 'useURLToGetData');



