<?php

add_action( 'wp_enqueue_scripts', function () {
	wp_enqueue_style( 'parent-style', get_stylesheet_directory_uri() . '/style.css','',true );
});


// 如果不存在定时任务，则创建一个整点的定时任务
if (!wp_next_scheduled('fetch_trustpilot_data_on_hour')) {
    // 计算下一个整点时间
    $timestamp = strtotime(date('Y-m-d H:00:00', strtotime('+1 hour')));
    wp_schedule_event($timestamp, 'hourly', 'fetch_trustpilot_data_on_hour');
}

function get_trustpilot_data() {
    $response = wp_remote_get('Your API'); // 这里填入获取数据的地址
    
    if (is_wp_error($response)) {
        return 'Error retrieving data';
    }
    
    $body = wp_remote_retrieve_body($response);
    $data = json_decode($body, true);
    
    if ($data['code'] === '0000') {
        return json_decode($data['data'], true);
    } else {
        return 'Error in API response: ' . $data['data'];
    }
}

// 注册trustpilot_data为全局变量
function set_trustpilot_data() {
    global $trustpilot_data;
    $trustpilot_data = get_trustpilot_data();
}
add_action('wp_head', 'set_trustpilot_data');

// 事件触发时调用的函数
function fetch_trustpilot_data_on_hour() {
    // 你的获取数据逻辑
    global $trustpilot_data;
    $trustpilot_data = get_trustpilot_data();

    // 将数据存储在 transient 或者 option 中，以便稍后使用
    set_transient('trustpilot_data', $trustpilot_data, HOUR_IN_SECONDS); // 缓存数据一小时
}

add_action('fetch_trustpilot_data_on_hour', 'fetch_trustpilot_data_on_hour');

// 注册短代码以显示 Trustpilot 评论模块
function reviews_shortcode() {
    ob_start();
    include get_stylesheet_directory() . '/tp_plugin.php'; // 加载 tp_plugin.php 模板文件
    return ob_get_clean();
}
add_shortcode('easy_reviews', 'reviews_shortcode');
