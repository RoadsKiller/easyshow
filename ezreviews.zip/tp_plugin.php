<?php
/**
 * The template for displaying the footer
 *
 * Contains the closing of the #content div and all content after.
 *
 * @link https://developer.wordpress.org/themes/basics/template-files/#template-partials
 *
 * @package Blocksy
 */

?>
<?php
$trustpilot_data = get_transient('tp_data_transient');


// 确保数据存在并且是数组
if (is_array($trustpilot_data)) :
?>
    <link rel="stylesheet" href="<?php echo plugin_dir_url(__FILE__).'/css/index1.css'?>">
    <link rel="stylesheet" href="<?php echo plugin_dir_url(__FILE__).'/css/swiper-bundle.min.css'?>">

    <script src="<?php echo plugin_dir_url(__FILE__).'/js/swiper-bundle.min.js'?>"></script>
    
    <div class="tp-container">
        <!-- Left Area -->
        <div class="tp-content-left tp-entity-grade">
            <!-- 这里是你的trustpilot对应的主页 -->
            <a target="_blank" href="<?php echo esc_url($trustpilot_data['trustpilot_url']); ?>">
                <!-- Trustpilot账户的“段位”：这部分可以获取api里的“段位”名称来显示 -->
                <div class="grade-words"><?php echo esc_html($trustpilot_data['grades_name']); ?></div>
                <!-- Trustpilot账户的等级：这部分可以获取api里的等级图片来显示 -->
                <div class="grade-stars">
                    <img src="<?php echo esc_url($trustpilot_data['grades_img']); ?>" alt="">
                </div>
                <!-- Trustpilot账户的所有评论数：这部分可以获取api里的总评论数来显示 -->
                <div class="grade-total-num-reviews">
                    Based on <span class="total-num-reviews"><?php echo esc_html($trustpilot_data['rv_total_num']) . ' reviews'; ?></span>
                </div>
                <!-- Trustpilot的logo -->
                <div class="grade-tp-logo">
                    <svg viewBox="0 0 140 34" fill="none" xmlns="http://www.w3.org/2000/svg">
                        <path
                            d="M36.785 11.97h14.173v2.597h-5.572v14.602H42.32V14.567h-5.548v-2.598h.012zm13.568 4.745h2.62v2.404h.049c.087-.34.247-.668.482-.984a4.57 4.57 0 0 1 1.965-1.517 3.456 3.456 0 0 1 1.248-.243c.32 0 .556.012.68.025.123.012.246.036.382.048v2.646a9.09 9.09 0 0 0-.605-.085 5.198 5.198 0 0 0-.606-.036c-.47 0-.914.097-1.334.28-.42.181-.779.46-1.087.813a4.107 4.107 0 0 0-.742 1.335c-.185.534-.272 1.14-.272 1.833v5.923h-2.792V16.715h.012zM70.618 29.17h-2.743v-1.736h-.05c-.346.632-.852 1.13-1.532 1.506-.68.376-1.372.57-2.076.57-1.668 0-2.88-.4-3.62-1.214-.742-.813-1.113-2.039-1.113-3.678v-7.902h2.793v7.635c0 1.093.21 1.87.643 2.319.42.449 1.025.68 1.791.68.593 0 1.075-.085 1.47-.268.396-.182.717-.412.952-.716.247-.291.42-.655.532-1.068.11-.413.16-.862.16-1.347v-7.223h2.793V29.17zm4.757-3.993c.087.8.395 1.36.927 1.687.543.316 1.186.486 1.94.486.26 0 .556-.025.89-.061.333-.037.654-.122.939-.23.296-.11.53-.28.728-.498.186-.22.272-.498.26-.85a1.163 1.163 0 0 0-.395-.862c-.248-.23-.556-.4-.94-.546a9.56 9.56 0 0 0-1.31-.352c-.494-.097-.988-.207-1.494-.316a14.42 14.42 0 0 1-1.508-.413 4.632 4.632 0 0 1-1.297-.655 2.898 2.898 0 0 1-.915-1.044c-.234-.425-.346-.947-.346-1.578 0-.68.173-1.238.507-1.7a3.821 3.821 0 0 1 1.273-1.104 5.973 5.973 0 0 1 1.717-.595c.63-.109 1.236-.17 1.804-.17.655 0 1.285.073 1.879.207a4.885 4.885 0 0 1 1.618.667c.482.304.877.704 1.199 1.19.321.485.519 1.08.605 1.772H80.54c-.136-.655-.433-1.104-.914-1.323-.482-.23-1.038-.34-1.656-.34-.198 0-.433.012-.704.049a3.918 3.918 0 0 0-.767.182 1.666 1.666 0 0 0-.605.388.93.93 0 0 0-.247.668c0 .34.123.607.358.813.235.206.544.376.927.522.383.134.816.255 1.31.352.494.097 1 .206 1.52.316.506.109 1 .255 1.495.412.494.158.926.377 1.31.656.383.279.692.619.926 1.032.235.412.359.934.359 1.541 0 .74-.173 1.36-.52 1.882-.345.51-.79.934-1.334 1.25a6.34 6.34 0 0 1-1.829.704 9.334 9.334 0 0 1-1.99.218 8.585 8.585 0 0 1-2.223-.267c-.68-.182-1.273-.449-1.767-.8a3.99 3.99 0 0 1-1.174-1.348c-.284-.534-.433-1.178-.457-1.918h2.817v-.024zm9.218-8.46h2.113v-3.74h2.793v3.74h2.52v2.05H89.5v6.653c0 .29.012.534.037.752.024.207.086.389.173.534a.79.79 0 0 0 .407.328c.186.073.42.11.742.11.197 0 .395 0 .593-.013.198-.012.395-.036.593-.085v2.124c-.309.037-.618.061-.902.097a7.355 7.355 0 0 1-.902.049c-.741 0-1.334-.073-1.78-.206-.444-.134-.803-.34-1.05-.607-.26-.267-.42-.595-.519-.996a7.342 7.342 0 0 1-.16-1.371V18.79h-2.113v-2.076h-.025zm9.403 0h2.645v1.686h.05c.394-.728.938-1.238 1.642-1.553a5.499 5.499 0 0 1 2.287-.474c1 0 1.865.17 2.607.522.741.34 1.359.814 1.853 1.42.494.607.853 1.311 1.1 2.113a8.71 8.71 0 0 1 .371 2.573c0 .837-.111 1.65-.334 2.428a6.436 6.436 0 0 1-1.001 2.087 4.89 4.89 0 0 1-1.705 1.445c-.692.364-1.495.546-2.434.546a6.95 6.95 0 0 1-1.224-.11 5.455 5.455 0 0 1-1.173-.351 4.254 4.254 0 0 1-1.039-.62 3.871 3.871 0 0 1-.803-.873h-.05v6.215h-2.792V16.715zm9.762 6.238a6.11 6.11 0 0 0-.222-1.638 4.391 4.391 0 0 0-.668-1.408 3.374 3.374 0 0 0-1.099-.984 3.129 3.129 0 0 0-1.52-.376c-1.174 0-2.064.4-2.657 1.202-.593.801-.89 1.87-.89 3.204 0 .631.075 1.214.235 1.748.16.534.383.996.704 1.384.31.389.68.692 1.113.91.432.231.939.34 1.507.34.643 0 1.174-.133 1.619-.388a3.389 3.389 0 0 0 1.087-.995c.284-.413.495-.875.618-1.396a7.683 7.683 0 0 0 .173-1.603zm4.93-10.985h2.793v2.598h-2.793v-2.598zm0 4.746h2.793V29.17h-2.793V16.715zm5.289-4.746h2.793v17.2h-2.793v-17.2zm11.356 17.54c-1.014 0-1.916-.17-2.706-.497a5.977 5.977 0 0 1-2.014-1.36 5.908 5.908 0 0 1-1.249-2.076 7.888 7.888 0 0 1-.432-2.646c0-.947.148-1.82.432-2.622a5.91 5.91 0 0 1 1.249-2.075c.543-.583 1.223-1.032 2.014-1.36.79-.328 1.692-.498 2.706-.498 1.013 0 1.915.17 2.706.498.791.328 1.458.79 2.014 1.36a5.893 5.893 0 0 1 1.248 2.075c.284.801.432 1.675.432 2.622 0 .96-.148 1.845-.432 2.646a5.891 5.891 0 0 1-1.248 2.076c-.544.583-1.223 1.032-2.014 1.36-.791.327-1.693.497-2.706.497zm0-2.173c.618 0 1.161-.133 1.618-.388a3.42 3.42 0 0 0 1.125-1.008c.296-.412.506-.886.655-1.408.136-.522.21-1.056.21-1.602 0-.534-.074-1.056-.21-1.59a4.13 4.13 0 0 0-.655-1.408 3.386 3.386 0 0 0-1.125-.995c-.457-.255-1-.389-1.618-.389-.618 0-1.162.134-1.619.389a3.52 3.52 0 0 0-1.124.995 4.347 4.347 0 0 0-.655 1.408 6.387 6.387 0 0 0-.211 1.59c0 .546.075 1.08.211 1.602s.358.996.655 1.408c.296.413.667.753 1.124 1.008.457.267 1.001.388 1.619.388zm7.216-10.62h2.113v-3.74h2.793v3.74h2.52v2.05h-2.52v6.653c0 .29.012.534.036.752.025.207.087.389.174.534a.787.787 0 0 0 .407.328c.186.073.42.11.742.11.197 0 .395 0 .593-.013.198-.012.395-.036.593-.085v2.124c-.309.037-.618.061-.902.097a7.359 7.359 0 0 1-.902.049c-.741 0-1.335-.073-1.78-.206-.444-.134-.803-.34-1.05-.607-.259-.267-.42-.595-.519-.996a7.37 7.37 0 0 1-.16-1.371V18.79h-2.113v-2.076h-.025z"
                            fill="#000" />
                        <path
                            d="M33.523 11.969H20.722L16.768 0 12.8 11.97 0 11.957l10.367 7.404-3.966 11.956 10.367-7.392 10.355 7.392-3.954-11.956 10.354-7.392z"
                            fill="#04DA8D" />
                        <path d="m24.058 22.069-.89-2.707-6.4 4.564 7.29-1.857z" fill="#126849" />
                    </svg>
                </div>
            </a>
        </div>

        <!-- Right Area -->
        <div class="tp-content-right tp-reviews-area" >
            <!-- slider按钮左 -->
            <div class="button-left">
                <button class="btn-style-prev" tabindex="0" role="button" aria-label="Previous slide" aria-controls="swiper-wrapper-61044292cca5a2f8a" type="button">&lt;</button>
            </div>
            <!-- Show Area -->
            <div class="reviews-area">
                <!-- 上：5星评论的显示区域 -->
                <div class="reviews-container swiper-container swiper-initialized swiper-horizontal swiper-backface-hidden">
                    <div class="show-reviews-area swiper-wrapper">
                        <?php foreach ($trustpilot_data['reviews'] as $index => $review) : ?>
                            
                                <div class="one-review-details swiper-slide" role="group" aria-label="<?php echo ($index + 1) . ' / ' . count($trustpilot_data['reviews']); ?>" data-swiper-slide-index="<?php echo esc_attr($index); ?>">
                                    <!-- 链接到对应的评论：这部分可以获取api里的reviews-1 url来显示 -->
                                    <a target="_blank" href="<?php echo esc_url($review['url']); ?>">
                                        <div class="orv-starts-and-time">
                                            <div class="orv-starts">  
                                                <img src="<?php echo esc_url($review['img_src']); ?>" alt="">
                                            </div>
                                            <div class="orv-time"><?php echo esc_html($review['time']); ?></div>
                                        </div>
                                        <div class="orv-title"><?php echo esc_html($review['title']); ?></div>
                                        <div class="orv-content"><?php echo esc_html($review['content']); ?></div>
                                        <div class="orv-username"><?php echo esc_html($review['username']); ?></div>
                                    </a>
                                </div>
                            
                        <?php endforeach; ?>
                    </div>
                </div>
            </div>

<?php endif; ?>
            <!-- slider按钮右 -->
            <div class="button-right">
                <button class="btn-style-next" type="button" tabindex="0" role="button" aria-label="Next slide" aria-controls="swiper-wrapper-61044292cca5a2f8a">&gt;</button>
            </div>
        </div>

    </div>

    <script>
		function adjustSwiperSettings() {
		  // 检查当前屏幕宽度
		  if (window.innerWidth <= 1000 && window.innerWidth > 661) {
			// 配置
			swiper.params.slidesPerView = 2;
			swiper.params.slidesPerGroup = 2;
			swiper.params.spaceBetween = 10;
		  } else if (window.innerWidth <= 660) {
			swiper.params.slidesPerView = 1;
			swiper.params.slidesPerGroup = 1;
			swiper.params.spaceBetween = 5;		 
		  }	else {
			// PC端配置
			swiper.params.slidesPerView = 3;
			swiper.params.slidesPerGroup = 2;
			swiper.params.spaceBetween = 30;
		  }
		  // 更新 Swiper 配置
		  swiper.update();
		};
		
		
        var swiper = new Swiper('.swiper-container', {
          slidesPerView: 3,
          spaceBetween: 30,
          slidesPerGroup: 2,
          loop: true,
          loopFillGroupWithBlank: true,
          pagination: {
            el: '.swiper-pagination',
            clickable: true,
          },
          navigation: {
            nextEl: '.btn-style-next',
            prevEl: '.btn-style-prev',
          },
			 
        });
		
		// 页面加载时调用一次
		adjustSwiperSettings();
		
		// 当窗口大小变化时重新调整配置
		window.addEventListener('resize', adjustSwiperSettings);
    </script>


